# Laundry Delivery App | Work in Progress
• Constructing the back-end of a Delivery App using the Kivy library in Python in order to launch it on multiple Operating Systems. E.g. IOS and Android. 
• Implementing the Flask framework to design an appealing front-end for the product. 
• Creating a MySQL database for data analysis and storage from acquired client’s data.

# Backgroud
This app will be used to allow users to have a more streamlined customer experience with The Laundry People. Customers will be able to use this app to order our services online, either through mobile or desktop.

# Current State of App
User Submission and preliminary Data Storage with SQLite have been implemented, working on Flask functionality and MySQL. 
